package hanze.lab.testzip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestZipApplicationTests {

	@Test
	void contextLoads() {
	}

}
